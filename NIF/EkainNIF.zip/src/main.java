public class main {

	public static void main(String[] args) {
		nif n1 = new nif();
		n1.leer();
		System.out.println(n1);
	}
}